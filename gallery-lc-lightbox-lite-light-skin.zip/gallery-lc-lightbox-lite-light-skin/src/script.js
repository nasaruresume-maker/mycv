    lc_lightbox('.lightbox', {
      wrap_class: 'lcl_fade_oc',
      gallery   : true,
      thumb_attr: 'data-lcl-thumb',
      skin      : 'light',
      radius    : 4,
      padding   : 0,
      border_w  : 0
    });