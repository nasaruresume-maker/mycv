# Gallery LC Lightbox Lite Light Skin

A Pen created on CodePen.

Original URL: [https://codepen.io/Puma-Murca/pen/emmMpYG](https://codepen.io/Puma-Murca/pen/emmMpYG).

